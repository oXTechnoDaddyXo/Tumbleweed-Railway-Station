--[[
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║           T U M B L E W E E D   M A P                             ║
    ║           ────────────────────────────                            ║
    ║            Tumbleweed Railway  Station                            ║
    ║            Redemption Map                                         ║
    ║                                                                   ║
    ║                                                                   ║
    ║                                                                   ║
    ╠═══════════════════════════════════════════════════════════════════╣
    ║   Server:    Destiny Flats RP                                     ║
    ║   Creator:   oXTechnoKhaliXo                                      ║
    ║   Discord:   https://discord.gg/djt7QQMkVa                        ║
    ╠═══════════════════════════════════════════════════════════════════╣
    ║   © 2026 oXTechnoKhaliXo | All Rights Reserved                    ║
    ╚═══════════════════════════════════════════════════════════════════╝
]]
fx_version 'adamant'
game       'rdr3'
this_is_a_map "yes"
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

name        'Tumbleweed Trainstation'
author      'oXTechnoKhaliXo'
description 'Little ymap near the Tumbleweed Mine'
version     '1.0.0'
files {
  'stream/tumbleweed_miningstation.ymap',
}