# tumbleweed_miningstation
RedM ymap allowing players to wait for the next Train.
Compatible with each Train Script.

# Requirements
- VORP Core
- Any Train Script

# Installation
- Extract .zip contents and place the `tumbleweed_miningstation` folder in your server's `resources/` folder (or `resources/[VORP]/` if preferred).
- Add `ensure tumbleweed_miningstation` to your server.cfg file.

# Notes
- This map is open source. You can edit whatever you want.

## Original Author
oXTechnoKhaliXo
- https://github.com/oXTechnoDaddyXo
